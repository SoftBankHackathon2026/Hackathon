"""Bounded private HTTP check; no redirects, proxies, credentials, or response logs."""
import os
import time
import urllib.error
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


http = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
successes = 0
target = int(os.environ["SUCCESSES"])
attempts = int(os.environ["ATTEMPTS"])
for attempt in range(attempts):
    try:
        request = urllib.request.Request(os.environ["PROBE_URL"], headers={"Cache-Control": "no-cache"})
        with http.open(request, timeout=int(os.environ["TIMEOUT"])) as response:
            valid = response.status == 200 and response.headers.get("X-Launchpad-Release") == os.environ["EXPECTED_RELEASE"]
        successes = successes + 1 if valid else 0
    except (OSError, urllib.error.URLError):
        successes = 0
    if successes >= target:
        print("candidate health and release identity verified", flush=True)
        raise SystemExit(0)
    if attempt + 1 < attempts:
        time.sleep(int(os.environ["INTERVAL"]))
print("candidate health or release identity check failed", flush=True)
raise SystemExit(1)
