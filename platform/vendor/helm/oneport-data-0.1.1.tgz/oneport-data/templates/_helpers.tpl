{{- define "oneport-data.ownerLabels" -}}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/name: oneport-data
app.kubernetes.io/managed-by: Helm
launchpad.io/application: {{ .Values.application | quote }}
launchpad.io/environment: {{ .Values.environment | quote }}
{{- end -}}

{{- define "oneport-data.labels" -}}
{{ include "oneport-data.ownerLabels" . }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | quote }}
{{- end -}}

{{- define "oneport-data.resources" -}}
requests:
  cpu: {{ printf "%vm" .cpuRequestMilli | quote }}
  memory: {{ printf "%vMi" .memoryRequestMi | quote }}
limits:
  cpu: {{ printf "%vm" .cpuLimitMilli | quote }}
  memory: {{ printf "%vMi" .memoryLimitMi | quote }}
{{- end -}}

{{- define "oneport-data.validate" -}}
{{- if ne .Release.Namespace "oneport-apps" }}{{ fail "oneport-data must use namespace oneport-apps" }}{{ end -}}
{{- if gt (len .Release.Name) 40 }}{{ fail "release name must be at most 40 characters" }}{{ end -}}
{{- if not (or .Values.postgresql.enabled .Values.redis.enabled) }}{{ fail "enable PostgreSQL or Redis before installing oneport-data" }}{{ end -}}
{{- range (list .Values.postgresql.resources .Values.redis.resources) -}}
{{- if gt .cpuRequestMilli .cpuLimitMilli }}{{ fail "CPU request exceeds limit" }}{{ end -}}
{{- if gt .memoryRequestMi .memoryLimitMi }}{{ fail "memory request exceeds limit" }}{{ end -}}
{{- end -}}
{{- if gt (int (add .Values.redis.maxMemoryMi 64)) (int .Values.redis.resources.memoryLimitMi) }}{{ fail "Redis limit must leave at least 64Mi above maxmemory" }}{{ end -}}
{{- $secret := lookup "v1" "Secret" .Release.Namespace .Values.credentialsSecret -}}
{{- if $secret -}}
{{- if ne $secret.metadata.uid .Values.credentialsSecretUid }}{{ fail "data credentials Secret was replaced; reconcile its UID before deployment" }}{{ end -}}
{{- if not $secret.immutable }}{{ fail "data credentials Secret must be immutable" }}{{ end -}}
{{- $labels := default dict $secret.metadata.labels -}}
{{- if ne (get $labels "launchpad.io/application") .Values.application }}{{ fail "data credentials Secret belongs to another application" }}{{ end -}}
{{- if ne (get $labels "launchpad.io/environment") .Values.environment }}{{ fail "data credentials Secret belongs to another environment" }}{{ end -}}
{{- end -}}
{{- $pg := lookup "apps/v1" "StatefulSet" .Release.Namespace (printf "%s-postgres" .Release.Name) -}}
{{- $pvc := lookup "v1" "PersistentVolumeClaim" .Release.Namespace (printf "data-%s-postgres-0" .Release.Name) -}}
{{- if and $pvc (not $pg) }}{{ fail "retained PostgreSQL PVC exists without its StatefulSet; explicit recovery of the original data release is required" }}{{ end -}}
{{- if $pg -}}
{{- if not .Values.postgresql.enabled }}{{ fail "disabling an existing PostgreSQL requires the complete-delete operation" }}{{ end -}}
{{- range $pg.spec.volumeClaimTemplates -}}
{{- if ne .spec.resources.requests.storage (printf "%vGi" $.Values.postgresql.storageGi) }}{{ fail "changing PostgreSQL storage requires a volume migration" }}{{ end -}}
{{- end -}}
{{- range (index $pg.spec.template.spec.containers 0).env -}}
{{- if and (eq .name "APP_DB_USER") (ne .value $.Values.postgresql.username) }}{{ fail "changing an initialized database username requires a migration" }}{{ end -}}
{{- if and (eq .name "APP_DB_NAME") (ne .value $.Values.postgresql.database) }}{{ fail "changing an initialized database name requires a migration" }}{{ end -}}
{{- end -}}
{{- range $pg.spec.template.spec.volumes -}}
{{- if and (eq .name "credentials") (ne .secret.secretName $.Values.credentialsSecret) }}{{ fail "changing PostgreSQL credentials requires a credential rotation procedure" }}{{ end -}}
{{- end -}}
{{- end -}}
{{- $redis := lookup "apps/v1" "Deployment" .Release.Namespace (printf "%s-redis" .Release.Name) -}}
{{- if and $redis (not .Values.redis.enabled) }}{{ fail "disabling an existing Redis requires the complete-delete operation" }}{{ end -}}
{{- if $redis -}}
{{- range $redis.spec.template.spec.volumes -}}
{{- if and (eq .name "credentials") (ne .secret.secretName $.Values.credentialsSecret) }}{{ fail "changing Redis credentials requires a credential rotation procedure" }}{{ end -}}
{{- end -}}
{{- end -}}
{{- end -}}
