# oneport-data

앱·환경 하나에 전용 PostgreSQL/Redis를 구성하는 별도 Helm 릴리스입니다.
앱 이미지 업데이트·롤백에서 데이터 릴리스를 함께 변경하지 않습니다.

차트 버전은 0.1.1입니다.

- PostgreSQL: 단일 StatefulSet, PVC 기본 1Gi, local-path, 앱용 비관리자 DB 계정
- Redis: 단일 Deployment, 인증 필수, 기본 16Mi 캐시, AOF/snapshot/PVC 없음
- 자격증명: 플랫폼이 먼저 만든 immutable Opaque Secret의 이름과 UID만 참조
- 기본 이미지와 설정: `values.yaml`; 허용 입력: `values.schema.json`
- Secret 내용·비밀번호를 chart/values/Helm 인자에 저장하지 않음
- PostgreSQL PVC는 일반 StatefulSet 삭제/scale 시 보존; 앱 전체 삭제에서 UID를 확인해 별도 정리
- StatefulSet 없이 PostgreSQL PVC만 남아 있으면 자동 설치/업데이트를 거부하고 원래 데이터 릴리스의 명시적 복구를 요구
- Namespace·ServiceAccount·RBAC·외부 DB 경로를 생성하지 않음

```bash
helm lint infra/onprem/charts/oneport-data --strict -n oneport-apps \
  -f infra/onprem/examples/helm/data-postgres-redis.yaml
```

예제 Secret 이름/UID는 렌더링용 자리표시자입니다. 실제 설치 전 자격증명을 준비하고 참조를 교체합니다.
`helm test`는 PostgreSQL 인증/SELECT 1/앱 계정 권한 및 Redis 인증/쓰기/읽기를 검사합니다.
검사는 Job 훅이므로 로그는 `kubectl logs job/<release>-helm-test --all-containers=true`로 확인합니다.

`helm uninstall` 이후에도 PVC와 외부 자격증명 Secret은 남습니다. 같은 release 이름으로 재설치해 기존 디스크를 자동 인수하지 않습니다.
원래 DB/계정·Secret UID·스토리지 설정을 확인하는 복구가 필요하며, 새 비밀번호 발급이나 PVC 자동 삭제로 이 오류를 우회하지 않습니다.
새 DB를 만들려는 경우에는 별도의 데이터 영구 삭제 요청으로 이전 자원을 정리한 뒤 설치합니다.

자격증명 준비, 데이터 보존·완전 삭제와 전체 실행 순서는
[플랫폼 전달 문서](../../docs/helm-platform-handoff.md)를 따릅니다.
