#!/bin/sh
set -eu
# Official entrypoint runs this once, on a fresh PGDATA. Psql quoting protects
# identifiers/passwords, and error output never exposes substituted credentials.
APP_DB_PASSWORD="$(cat /run/oneport/postgres-app-password)"
export APP_DB_PASSWORD
if ! psql --username "$POSTGRES_USER" --dbname postgres --set ON_ERROR_STOP=1 >/dev/null 2>&1 <<'SQL'
\getenv app_user APP_DB_USER
\getenv app_db APP_DB_NAME
\getenv app_password APP_DB_PASSWORD
CREATE ROLE :"app_user" LOGIN PASSWORD :'app_password' NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;
CREATE DATABASE :"app_db" OWNER :"app_user";
SQL
then
  echo "Oneport application database initialization failed" >&2
  exit 1
fi
unset APP_DB_PASSWORD
