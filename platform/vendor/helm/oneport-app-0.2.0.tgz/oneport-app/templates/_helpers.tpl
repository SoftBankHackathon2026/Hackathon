{{- define "oneport-app.name" -}}
{{- .Release.Name -}}
{{- end -}}

{{- define "oneport-app.selector" -}}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/component: web
launchpad.io/application: {{ .Values.application | quote }}
launchpad.io/environment: {{ .Values.environment | quote }}
{{- end -}}

{{- define "oneport-app.labels" -}}
{{ include "oneport-app.selector" . }}
app.kubernetes.io/name: oneport-app
app.kubernetes.io/managed-by: Helm
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | quote }}
{{- end -}}

{{- define "oneport-app.probeLabels" -}}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/component: probe
app.kubernetes.io/name: oneport-app
app.kubernetes.io/managed-by: Helm
launchpad.io/application: {{ .Values.application | quote }}
launchpad.io/environment: {{ .Values.environment | quote }}
{{- end -}}

{{- define "oneport-app.validate" -}}
{{- if ne .Release.Namespace "oneport-apps" }}{{ fail "oneport-app must use namespace oneport-apps" }}{{ end -}}
{{- if gt (len .Release.Name) 40 }}{{ fail "release name must be at most 40 characters" }}{{ end -}}
{{- if and .Release.IsInstall .Values.route.enabled }}{{ fail "the first installation must keep route.enabled=false; publish with an upgrade after private checks" }}{{ end -}}
{{- if gt .Values.resources.cpuRequestMilli .Values.resources.cpuLimitMilli }}{{ fail "CPU request exceeds limit" }}{{ end -}}
{{- if gt .Values.resources.memoryRequestMi .Values.resources.memoryLimitMi }}{{ fail "memory request exceeds limit" }}{{ end -}}
{{- if gt .Values.analysis.consecutiveSuccesses .Values.analysis.maxAttempts }}{{ fail "analysis successes exceed attempts" }}{{ end -}}
{{- $duration := add (mul .Values.analysis.maxAttempts (add .Values.analysis.timeoutSeconds .Values.analysis.intervalSeconds)) 5 -}}
{{- if gt (int $duration) (int .Values.analysis.jobDeadlineSeconds) }}{{ fail "analysis deadline is too short for configured attempts" }}{{ end -}}
{{- $weights := .Values.strategy.canary.weights -}}
{{- $previous := 0 -}}
{{- range $weight := $weights -}}
{{- if le (int $weight) (int $previous) }}{{ fail "canary weights must increase strictly" }}{{ end -}}
{{- $previous = $weight -}}
{{- end -}}
{{- if ne (int $previous) 100 }}{{ fail "canary weights must end at 100" }}{{ end -}}
{{- $names := dict "PORT" true "LAUNCHPAD_RELEASE_ID" true -}}
{{- range $name, $_ := .Values.env -}}
{{- if or (hasKey $names $name) (has $name (list "DATABASE_URL" "REDIS_URL")) }}{{ fail (printf "reserved environment variable: %s" $name) }}{{ end -}}
{{- if and $.Values.observability.python (hasPrefix "OTEL_" $name) }}{{ fail "OTEL_* settings are managed by platform instrumentation" }}{{ end -}}
{{- $_ := set $names $name true -}}
{{- end -}}
{{- range .Values.secretBindings -}}
{{- if hasKey $names .env }}{{ fail (printf "duplicate or reserved environment variable: %s" .env) }}{{ end -}}
{{- if and $.Values.observability.python (or (hasPrefix "OTEL_" .env) (eq .env "PYTHONPATH")) }}{{ fail "instrumentation settings cannot be replaced by Secret bindings" }}{{ end -}}
{{- $_ := set $names .env true -}}
{{- $secret := lookup "v1" "Secret" $.Release.Namespace .name -}}
{{- if $secret -}}
{{- if ne $secret.metadata.uid .uid }}{{ fail "a bound Secret was replaced; reconcile its UID before deployment" }}{{ end -}}
{{- if not $secret.immutable }}{{ fail "application Secret bindings must be immutable" }}{{ end -}}
{{- $labels := default dict $secret.metadata.labels -}}
{{- if or (ne (get $labels "launchpad.io/application") $.Values.application) (ne (get $labels "launchpad.io/environment") $.Values.environment) }}{{ fail "Secret binding belongs to another application/environment" }}{{ end -}}
{{- if not (hasKey (default dict $secret.data) .key) }}{{ fail "Secret binding key is missing" }}{{ end -}}
{{- end -}}
{{- end -}}
{{- if and .Values.observability.python (empty .Values.observability.image) }}{{ fail "Python instrumentation requires a pinned init image" }}{{ end -}}
{{- $existing := lookup "argoproj.io/v1alpha1" "Rollout" .Release.Namespace .Release.Name -}}
{{- if $existing -}}
{{- $selector := default dict $existing.spec.selector.matchLabels -}}
{{- if or (ne (get $selector "launchpad.io/application") .Values.application) (ne (get $selector "launchpad.io/environment") .Values.environment) }}{{ fail "application and environment are immutable for an existing Helm release" }}{{ end -}}
{{- $mode := ternary "blueGreen" "canary" (hasKey $existing.spec.strategy "blueGreen") -}}
{{- if ne $mode .Values.strategy.type }}{{ fail "changing an existing rollout strategy requires an explicit migration" }}{{ end -}}
{{- end -}}
{{- end -}}

{{- define "oneport-app.probePodSpec" -}}
{{- $root := .root -}}
serviceAccountName: oneport-runtime
automountServiceAccountToken: false
restartPolicy: Never
nodeSelector:
  kubernetes.io/arch: amd64
securityContext:
  runAsNonRoot: true
  runAsUser: 10001
  runAsGroup: 10001
  seccompProfile:
    type: RuntimeDefault
containers:
  - name: health
    image: {{ $root.Values.analysis.image | quote }}
    imagePullPolicy: IfNotPresent
    command: [python, -B, -u, -c]
    args:
      - |
{{ $root.Files.Get "files/probe.py" | indent 8 }}
    env:
      - name: PROBE_URL
        value: {{ printf "http://%s.%s.svc.cluster.local%s" .service $root.Release.Namespace $root.Values.healthPath | quote }}
      - name: EXPECTED_RELEASE
        value: {{ .releaseId | quote }}
      - name: SUCCESSES
        value: {{ $root.Values.analysis.consecutiveSuccesses | quote }}
      - name: ATTEMPTS
        value: {{ $root.Values.analysis.maxAttempts | quote }}
      - name: INTERVAL
        value: {{ $root.Values.analysis.intervalSeconds | quote }}
      - name: TIMEOUT
        value: {{ $root.Values.analysis.timeoutSeconds | quote }}
    resources:
      requests: {cpu: 10m, memory: 32Mi}
      limits: {cpu: 100m, memory: 64Mi}
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities:
        drop: [ALL]
{{- end -}}
