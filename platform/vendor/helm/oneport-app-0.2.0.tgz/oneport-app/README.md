# oneport-app

Oneport의 Helm 기반 웹 앱 배포 차트입니다. Argo Rollout, private Service 두 개, 후보 검사 AnalysisTemplate/Job을 생성합니다.
블루그린은 Ingress, 카나리는 TraefikService + IngressRoute를 사용합니다. 공개 경로는 최초 검증 전까지 기본 비활성입니다.

- 버전: 0.2.0, Helm 3.22.0 / Kubernetes 1.35 / Argo Rollouts 1.10 / Traefik 3 기준
- namespace: `oneport-apps`, SA: 기존 `oneport-runtime`, token automount 비활성
- 이미지: linux/amd64, immutable digest 필수; 앱 소유권과 registry allowlist는 플랫폼에서 확인
- `values.schema.json`이 지원 필드·자료형·상한을 검사합니다. values를 Helm 템플릿으로 평가하지 않습니다.
- Secret binding은 name/key/UID를 받습니다. 비밀번호 원문을 values에 넣지 않습니다.
- Helm 종료 코드와 Argo/application 성공은 별도로 확인합니다.
- 선택한 Python 앱에 non-root init 컨테이너로 자동 계측을 주입합니다. [관측 구성과 플랫폼 연결](../../observability/README.md)을 참고하세요.

```bash
helm lint infra/onprem/charts/oneport-app --strict -n oneport-apps \
  -f infra/onprem/examples/helm/app-bluegreen.yaml
helm template demo-app infra/onprem/charts/oneport-app -n oneport-apps \
  -f infra/onprem/examples/helm/app-canary.yaml
```

예제는 공개 Python 데모 이미지로 실행할 수 있으며, 운영용으로는 플랫폼이 빌드한 이미지와 앱 설정을 전달합니다.
배포마다 고정 릴리스 이름에 새로운 `releaseId`/image를 전달합니다. 최초 배포는 `route.enabled=false`로 시작해
Rollout readiness와 `helm test`를 확인한 뒤 공개합니다.
최초 설치에서 `route.enabled=true`는 거부하며 공개는 이후 upgrade로 수행합니다.
기존 릴리스의 `application`/`environment`는 변경할 수 없습니다.
수동 카나리의 단계가 `[100]`이면 후보 검사 후 100% 전환 전에 한 번 승인을 기다립니다.
헬스체크는 HTTP 200과 정확한 `X-Launchpad-Release` 헤더를 요구합니다.

## 사용자 지정 카나리 비율

플랫폼은 사용자가 입력한 비율 목록을 `strategy.canary.weights`에 전달합니다.
`[10, 50, 100]`은 기본값이며 고정 선택지가 아닙니다. 예를 들어 다음과 같이 지정할 수 있습니다.

```yaml
strategy:
  type: canary
  promotion: automatic
  canary:
    weights: [5, 20, 40, 70, 100]
    holdSeconds: 30
```

- 각 값은 새 버전에 전달할 트래픽의 누적 비율이며, 1~100 사이의 정수입니다. 비율의 합이 100일 필요는 없습니다.
- 목록은 비어 있지 않아야 하며 중복 없이 증가하고 마지막 값은 100이어야 합니다.
- 0.1.2부터 기존 8단계 제한을 해제해 최대 100단계까지 입력할 수 있습니다.
  `[10, 20, 30, 40, 50, 60, 70, 80, 90, 100]`처럼 일정한 간격도 가능합니다.
- 각 단계에서 지정한 시간만큼 대기하고 후보 검사를 수행합니다. 수동 모드는 100% 이전 각 단계의 검사 후 승인을 기다립니다.

전체 입력 매핑, 승인·중단·롤백, 최초 공개와 기존 SDK 전환 규칙은
[플랫폼 전달 문서](../../docs/helm-platform-handoff.md)를 따릅니다.
